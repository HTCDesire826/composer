<?php

class Pearlike_Baz
{
    public static $loaded = true;
}
