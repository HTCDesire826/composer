<?php

namespace ClassMap;

interface SomeInterface
{

}
