<?php

namespace Foo;

class MissingSpace{
}
